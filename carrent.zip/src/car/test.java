/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

/**
 *
 * 
 */
public class test {
    
    
    
    
    public static void main(String args[])
    
    {
    String status = "yes";
        
          if( status == "ye")
          {
              System.out.println("A");
          }
    else
          {
              System.out.println("B");
          }
            
        
        
    }
  

}
    
    

